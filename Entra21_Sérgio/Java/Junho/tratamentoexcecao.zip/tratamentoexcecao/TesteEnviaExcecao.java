package com.entra21.cursojavamanha.oop.exerciciospratica.tratamentoexcecao;

public class TesteEnviaExcecao {

	public static void main(String[] args) {
		
		String frase = null;
	    String novaFrase = null;
	    novaFrase = frase.toUpperCase(); // COLOCA EM MAISCULA
	    System.out.println("Frase antiga: "+frase);
	    System.out.println("Frase nova: "+novaFrase);
		
		
	}

}
